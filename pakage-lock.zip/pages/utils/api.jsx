export const api = "http://192.168.137.1:3000"; // Use o IP do hotspot

export default api;