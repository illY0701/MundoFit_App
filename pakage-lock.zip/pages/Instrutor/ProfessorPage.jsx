// ProfessorPage.jsx
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  ActivityIndicator,
  TextInput,
  Alert,
  Animated,
  Dimensions,
  ScrollView,
  Modal
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { createStackNavigator } from '@react-navigation/stack';
import { api } from '../utils/api';
import styles from './styles';
import { SafeAreaView } from 'react-native';


const Stack = createStackNavigator();
const { width } = Dimensions.get('window');

// ── Constants ─────────────────────────────────────────────────────────────────
const ALL_EXERCISES = [
  { id: 1, nm_exercicio: 'Agachamento' },
  { id: 2, nm_exercicio: 'Leg Press' },
  { id: 3, nm_exercicio: 'Cadeira Extensora' },
  { id: 4, nm_exercicio: 'Cadeira Flexora' },
];


// ── AlunosListScreen ──────────────────────────────────────────────────────────
function AlunosListScreen({ navigation, route }) {
  const { usuario } = route.params;
  const [alunos, setAlunos] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAlunos = async () => {
      try {
        const res = await fetch(`${api}/alunos`);
        setAlunos(await res.json());
      } catch {
        Alert.alert('Erro', 'Não foi possível carregar os alunos');
      } finally {
        setLoading(false);
      }
    };

    fetchAlunos();
  }, []);

  const refreshAlunos = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${api}/alunos`);
      setAlunos(await res.json());
    } catch {
      Alert.alert('Erro', 'Não foi possível atualizar a lista de alunos');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color="#C70039" />
      </View>
    );
  }

  const filtered = alunos.filter(a =>
    a.nm_aluno.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <View style={styles.searchInput}>
        <Ionicons name="search-outline" size={20} color="#C70039" style={{ marginRight: 8 }} />
        <TextInput
          placeholder="Buscar aluno..."
          placeholderTextColor="#666"
          value={searchQuery}
          onChangeText={setSearchQuery}
          style={{ flex: 1 }}
        />
</View>
      <FlatList
        data={filtered}
        keyExtractor={item => String(item.id)}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.card}
            onPress={() =>
              navigation.navigate('AlunoDetalhes', {
                aluno: item,
                usuario,
                refreshAlunos
              })
            }
          >
            <LinearGradient colors={['#C70039', '#900C3F']} style={styles.cardInner}>
              <Text style={styles.cardTitle}>{item.nm_aluno}</Text>
              <Text style={styles.cardText}>Peso: {item.cd_peso} kg</Text>
              <Text style={styles.cardText}>Altura: {item.cd_altura} cm</Text>
            </LinearGradient>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}


// ── AlunoDetalhesScreen ───────────────────────────────────────────────────────

function AlunoDetalhesScreen({ navigation, route }) {
  const { aluno, usuario, refreshAlunos } = route.params;
  const [treinos, setTreinos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingTreino, setEditingTreino] = useState(null);
  const [confirmDeleteVisible, setConfirmDeleteVisible] = useState(false);

  useEffect(() => {
    const fetchTreinos = async () => {
      try {
        const res = await fetch(`${api}/treinos?alunoId=${aluno.id}`);
        const data = await res.json();
        
        const groupedTreinos = data.reduce((acc, curr) => {
          if(curr.cd_fk_aluno !== aluno.id) return acc;
          
          const existing = acc.find(t => t.nm_treino === curr.nm_treino);
          if (existing) {
            existing.exercicios.push({
              id: curr.cd_fk_exercicio,
              nm_exercicio: curr.nm_fk_exercicio
            });
          } else {
            acc.push({
              id: curr.id,
              nm_treino: curr.nm_treino,
              ds_objetivo: curr.ds_objetivo,
              ds_observacao: curr.ds_observacao,
              dt_treino: curr.dt_treino,
              exercicios: [{
                id: curr.cd_fk_exercicio,
                nm_exercicio: curr.nm_fk_exercicio
              }]
            });
          }
          return acc;
        }, []);
        
        setTreinos(groupedTreinos);
      } catch {
        Alert.alert('Erro', 'Não foi possível carregar os treinos');
      } finally {
        setLoading(false);
      }
    };

    fetchTreinos();
  }, [aluno.id]);

  const refreshTreinos = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${api}/treinos?alunoId=${aluno.id}`);
      const data = await res.json();
      
      const groupedTreinos = data.reduce((acc, curr) => {
        if(curr.cd_fk_aluno !== aluno.id) return acc;
        
        const existing = acc.find(t => t.nm_treino === curr.nm_treino);
        if (existing) {
          existing.exercicios.push({
            id: curr.cd_fk_exercicio,
            nm_exercicio: curr.nm_fk_exercicio
          });
        } else {
          acc.push({
            id: curr.id,
            nm_treino: curr.nm_treino,
            ds_objetivo: curr.ds_objetivo,
            ds_observacao: curr.ds_observacao,
            dt_treino: curr.dt_treino,
            exercicios: [{
              id: curr.cd_fk_exercicio,
              nm_exercicio: curr.nm_fk_exercicio
            }]
          });
        }
        return acc;
      }, []);
      
      setTreinos(groupedTreinos);
    } catch {
      Alert.alert('Erro', 'Não foi possível atualizar os treinos');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteTreino = async (treinoNome) => {
    try {
      const res = await fetch(
        `${api}/treinos?treinoNome=${encodeURIComponent(treinoNome)}&alunoId=${aluno.id}`
      );
      const treinosParaExcluir = await res.json();
      
      // Filtro duplo para segurança
      const treinosDoAluno = treinosParaExcluir.filter(
        t => t.cd_fk_aluno === aluno.id && t.nm_treino === treinoNome
      );

      await Promise.all(
        treinosDoAluno.map(async (treino) => {
          await fetch(`${api}/treinos/${treino.id}`, { method: 'DELETE' });
        })
      );
      
      refreshTreinos();
      Alert.alert('Sucesso', 'Treino excluído com sucesso');
    } catch {
      Alert.alert('Erro', 'Não foi possível excluir o treino');
    }
  };

  const handleDeleteAluno = async () => {
    try {
      // Primeiro exclui todos os treinos do aluno
      const resTreinos = await fetch(`${api}/treinos?alunoId=${aluno.id}`);
      const treinosParaExcluir = await resTreinos.json();
      
      await Promise.all(
        treinosParaExcluir.map(async (treino) => {
          await fetch(`${api}/treinos/${treino.id}`, { method: 'DELETE' });
        })
      );

      // Depois exclui o aluno
      const res = await fetch(`${api}/alunos/${aluno.id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error();
      
      Alert.alert('Sucesso', 'Aluno excluído com sucesso', [{
        text: 'OK',
        onPress: () => {
          refreshAlunos();
          navigation.goBack();
        }
      }]);
    } catch {
      Alert.alert('Erro', 'Não foi possível excluir o aluno');
    }
  };

  if (loading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color="#C70039" />
      </View>
    );
  }

  return (
      <SafeAreaView style={styles.container}>
        <View style={styles.headerWrapper}>
    <LinearGradient 
      colors={['#C70039', '#900C3F']} 
      style={[styles.alunoHeader, { 
        paddingTop: 40, // Compensação precisa para altura do header
        marginTop: -28, // "Puxa" o gradiente para cima
      }]}
    >
      <Text style={styles.alunoNome}>{aluno.nm_aluno}</Text>
      <Text style={styles.alunoInfo}>Peso: {aluno.cd_peso} kg | Altura: {aluno.cd_altura} cm</Text>
    </LinearGradient>
</View>
      <View style={styles.buttonRow}>
        <TouchableOpacity
          style={[styles.actionButton, { backgroundColor: '#C70039' }]}
          onPress={() => {
            setEditingTreino(null);
            setModalVisible(true);
          }}
        >
          <Text style={styles.buttonText}>Adicionar Treino</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.actionButton, { backgroundColor: '#FF5733' }]}
          onPress={() => setConfirmDeleteVisible(true)}
        >
          <Text style={styles.buttonText}>Excluir Aluno</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={treinos}
        keyExtractor={item => String(item.id)}
        renderItem={({ item }) => (
          <View style={styles.treinoCard}>
            <View style={styles.treinoHeader}>
              <Text style={styles.treinoTitle}>{item.nm_treino}</Text>
              <View style={styles.treinoActions}>
                <TouchableOpacity onPress={() => {
                  setEditingTreino(item);
                  setModalVisible(true);
                }}>
                  <Ionicons name="create" size={24} color="#C70039" />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => handleDeleteTreino(item.nm_treino)}>
                  <Ionicons name="trash" size={24} color="#C70039" />
                </TouchableOpacity>
              </View>
            </View>
            
            <FlatList
              data={item.exercicios}
              keyExtractor={(ex, index) => `${item.id}-${index}`}
              renderItem={({ item: ex }) => (
                <Text style={styles.treinoText}>• {ex.nm_exercicio}</Text>
              )}
            />
            
            {item.ds_objetivo && <Text style={styles.treinoText}>Objetivo: {item.ds_objetivo}</Text>}
            {item.ds_observacao && <Text style={styles.treinoText}>Observação: {item.ds_observacao}</Text>}
            <Text style={styles.treinoDate}>Criado em: {new Date(item.dt_treino).toLocaleDateString()}</Text>
          </View>
        )}
        ListEmptyComponent={
          <Text style={styles.emptyText}>Nenhum treino cadastrado para este aluno</Text>
        }
      />

      <TreinoModal
        visible={modalVisible}
        onClose={() => setModalVisible(false)}
        alunoId={aluno.id}
        usuario={usuario}
        refreshTreinos={refreshTreinos}
        treino={editingTreino}
      />

      <Modal
        animationType="fade"
        transparent={true}
        visible={confirmDeleteVisible}
        onRequestClose={() => setConfirmDeleteVisible(false)}
      >
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <Text style={styles.modalText}>Tem certeza que deseja excluir este aluno permanentemente?</Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, { backgroundColor: '#900C3F' }]}
                onPress={handleDeleteAluno}
              >
                <Text style={styles.buttonText}>Excluir</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, { backgroundColor: '#666' }]}
                onPress={() => setConfirmDeleteVisible(false)}
              >
                <Text style={styles.buttonText}>Cancelar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}


// ── TreinoModal ───────────────────────────────────────────────────────────────

function TreinoModal({ visible, onClose, alunoId, usuario, refreshTreinos, treino }) {
  const [nmTreino, setNmTreino] = useState(treino?.nm_treino || '');
  const [objetivo, setObjetivo] = useState(treino?.ds_objetivo || '');
  const [observacao, setObservacao] = useState(treino?.ds_observacao || '');
  const [filterText, setFilterText] = useState('');
  const [selected, setSelected] = useState(treino?.exercicios?.map(e => e.id) || []);
  const [customExercise, setCustomExercise] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [diaSemana, setDiaSemana] = useState(treino?.diaSemana || '');
  
  const diasDisponiveis = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'];

  useEffect(() => {
    if (!visible) {
      setNmTreino(treino?.nm_treino || '');
      setObjetivo(treino?.ds_objetivo || '');
      setObservacao(treino?.ds_observacao || '');
      setFilterText('');
      setSelected(treino?.exercicios?.map(e => e.id) || []);
      setCustomExercise('');
      setDiaSemana(treino?.diaSemana || '');
    }
  }, [visible, treino]);

  const filteredExercises = ALL_EXERCISES.filter(ex =>
    ex.nm_exercicio.toLowerCase().includes(filterText.toLowerCase())
  );

  const toggleSelect = id =>
    setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  const handleAddCustomExercise = () => {
    if (customExercise.trim()) {
      setSelected(prev => [...prev, customExercise]);
      setCustomExercise('');
    }
  };

  const handleSubmit = async () => {
    if (!nmTreino.trim() || selected.length === 0 || !diaSemana) {
      Alert.alert('Erro', 'Preencha todos os campos obrigatórios: nome, exercícios e dia');
      return;
    }

    setSubmitting(true);
    try {
      const exercicios = selected.map(id => ({
        cd_fk_exercicio: id,
        nm_exercicio: typeof id === 'number' 
          ? ALL_EXERCISES.find(e => e.id === id)?.nm_exercicio 
          : id
      }));

      if (treino) {
        const res = await fetch(`${api}/treinos?treinoNome=${encodeURIComponent(treino.nm_treino)}&alunoId=${alunoId}`);
        const treinosAntigos = await res.json();
        
        await Promise.all(
          treinosAntigos.map(async (t) => {
            await fetch(`${api}/treinos/${t.id}`, { method: 'DELETE' });
          })
        );
      }

      await Promise.all(
        exercicios.map(async (ex) => {
          const res = await fetch(`${api}/treinos`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              nm_treino: nmTreino,
              nm_fk_exercicio: ex.nm_exercicio,
              cd_fk_exercicio: ex.cd_fk_exercicio,
              cd_fk_aluno: alunoId,
              cd_fk_professor: usuario.id,
              dt_treino: new Date().toISOString(),
              ds_objetivo: objetivo,
              ds_observacao: observacao,
              diaSemana: diaSemana
            })
          });
          if (!res.ok) throw new Error();
        })
      );

      refreshTreinos();
      onClose();
      Alert.alert('Sucesso', treino ? 'Treino atualizado!' : 'Treino cadastrado!');
    } catch {
      Alert.alert('Erro', 'Falha ao salvar treino');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      animationType="slide"
      transparent={false}
      visible={visible}
      onRequestClose={onClose}
    >
      <View style={styles.modalContainer}>
        <View style={styles.modalHeader}>
          <Text style={styles.modalTitle}>{treino ? 'Editar Treino' : 'Novo Treino'}</Text>
          <TouchableOpacity onPress={onClose}>
            <Ionicons name="close" size={28} color="#C70039" />
          </TouchableOpacity>
        </View>

        <TextInput
          style={styles.input}
          placeholder="Nome do Treino*"
          value={nmTreino}
          onChangeText={setNmTreino}
        />

        <Text style={styles.sectionTitle}>Dia da Semana*</Text>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.daysScroll}
        >
          {diasDisponiveis.map(dia => (
            <TouchableOpacity
              key={dia}
              style={[
                styles.dayButton,
                diaSemana === dia && styles.selectedDayButton
              ]}
              onPress={() => setDiaSemana(dia)}
            >
              <Text style={[
                styles.dayButtonText,
                diaSemana === dia && styles.selectedDayText
              ]}>
                {dia}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <TextInput
          style={styles.input}
          placeholder="Objetivo"
          value={objetivo}
          onChangeText={setObjetivo}
        />

        <TextInput
          style={[styles.input, styles.multiline]}
          placeholder="Observações"
          multiline
          value={observacao}
          onChangeText={setObservacao}
        />

        <Text style={styles.sectionTitle}>Exercícios*</Text>
        <TextInput
          style={styles.input}
          placeholder="Filtrar exercícios..."
          value={filterText}
          onChangeText={setFilterText}
        />

        <View style={styles.customExerciseContainer}>
          <TextInput
            style={[styles.input, { flex: 1 }]}
            placeholder="Ou digite um exercício personalizado"
            value={customExercise}
            onChangeText={setCustomExercise}
          />
          <TouchableOpacity
            style={styles.addButton}
            onPress={handleAddCustomExercise}
            disabled={!customExercise.trim()}
          >
            <Ionicons name="add" size={24} color="white" />
          </TouchableOpacity>
        </View>

        <FlatList
          data={filteredExercises}
          keyExtractor={item => String(item.id)}
          style={styles.exerciseList}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[
                styles.exerciseOption,
                selected.includes(item.id) && styles.selectedExercise
              ]}
              onPress={() => toggleSelect(item.id)}
              activeOpacity={0.7}
            >
              <Text style={styles.exerciseText}>{item.nm_exercicio}</Text>
              {selected.includes(item.id) && (
                <Ionicons name="checkmark" size={20} color="white" />
              )}
            </TouchableOpacity>
          )}
        />

        {selected.filter(id => typeof id === 'string').length > 0 && (
          <View style={styles.customExercisesSelected}>
            <Text style={styles.sectionTitle}>Exercícios Personalizados:</Text>
            {selected.filter(id => typeof id === 'string').map((ex, index) => (
              <View key={index} style={styles.customExerciseItem}>
                <Text style={styles.exerciseText}>{ex}</Text>
                <TouchableOpacity onPress={() => toggleSelect(ex)}>
                  <Ionicons name="close" size={20} color="#C70039" />
                </TouchableOpacity>
              </View>
            ))}
          </View>
        )}

        <TouchableOpacity
          style={styles.submitButton}
          onPress={handleSubmit}
          disabled={submitting}
        >
          <Text style={styles.buttonText}>
            {submitting ? 'Salvando...' : treino ? 'Atualizar Treino' : 'Salvar Treino'}
          </Text>
        </TouchableOpacity>
        {submitting && <ActivityIndicator color="#C70039" style={{ marginTop: 10 }} />}
      </View>
    </Modal>
  );
}


// ── ConfigScreen ──────────────────────────────────────────────────────────────

function ConfigScreen({ navigation, route }) {
  const { usuario } = route.params;
  const [professor, setProfessor] = useState(null);
  const [editando, setEditando] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showSuccess, setShowSuccess] = useState(false);
  const successScale = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`${api}/professores/${usuario.id}`);
        setProfessor(await res.json());
      } catch {
        Alert.alert('Erro', 'Não foi possível carregar perfil');
      } finally {
        setLoading(false);
      }
    })();
  }, [usuario.id]);

  const handleUpdate = async () => {
    if (
      !professor.nm_professor.trim() ||
      !professor.email_professor.trim() ||
      !professor.ds_especialidade.trim()
    ) {
      Alert.alert('Erro', 'Preencha todos os campos');
      return;
    }
    try {
      const res = await fetch(`${api}/professores/${professor.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nm_professor: professor.nm_professor,
          email_professor: professor.email_professor,
          ds_especialidade: professor.ds_especialidade
        })
      });
      if (!res.ok) throw new Error();
      const updated = await res.json();
      setProfessor(updated);
      setEditando(false);
      setShowSuccess(true);
      Animated.sequence([
        Animated.timing(successScale, { toValue: 1, duration: 300, useNativeDriver: true }),
        Animated.delay(1000),
        Animated.timing(successScale, { toValue: 0, duration: 300, useNativeDriver: true })
      ]).start(() => setShowSuccess(false));
    } catch {
      Alert.alert('Erro', 'Falha ao atualizar perfil');
    }
  };

  const handleLogout = () => {
    navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
  };

  if (loading || !professor) {
    return <ActivityIndicator size="large" color="#C70039" style={styles.loader} />;
  }

    return (
    <SafeAreaView style={styles.configContainer}>
      <View style={styles.profileHeader}>
        <View style={styles.profileIcon}>
          <Ionicons name="person-circle" size={42} color="#FFF5F5" />
        </View>
        <View>
          <Text style={styles.profileTitle}>{professor.nm_professor}</Text>
          <Text style={styles.profileSubtitle}>Perfil do Professor</Text>
        </View>
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.inputLabel}>Nome completo</Text>
        {editando ? (
          <TextInput
            style={styles.inputField}
            value={professor.nm_professor}
            onChangeText={t => setProfessor(p => ({ ...p, nm_professor: t }))}
          />
        ) : (
          <Text style={[styles.inputField, styles.readonlyField]}>{professor.nm_professor}</Text>
        )}
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.inputLabel}>E-mail</Text>
        {editando ? (
          <TextInput
            style={styles.inputField}
            value={professor.email_professor}
            onChangeText={t => setProfessor(p => ({ ...p, email_professor: t }))}
            keyboardType="email-address"
          />
        ) : (
          <Text style={[styles.inputField, styles.readonlyField]}>{professor.email_professor}</Text>
        )}
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.inputLabel}>Especialidade</Text>
        {editando ? (
          <TextInput
            style={styles.inputField}
            value={professor.ds_especialidade}
            onChangeText={t => setProfessor(p => ({ ...p, ds_especialidade: t }))}
          />
        ) : (
          <Text style={[styles.inputField, styles.readonlyField]}>{professor.ds_especialidade}</Text>
        )}
      </View>

      <View style={styles.buttonGroup}>
        <TouchableOpacity
          style={[styles.primaryButton, editando && { backgroundColor: '#900C3F' }]}
          onPress={editando ? handleUpdate : () => setEditando(true)}
        >
          <Ionicons name={editando ? 'save' : 'create'} size={20} color="#FFF5F5" />
          <Text style={styles.buttonText}>
            {editando ? 'SALVAR ALTERAÇÕES' : 'EDITAR PERFIL'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
  style={[styles.primaryButton, styles.secondaryButton]}
  onPress={handleLogout}
>
  <Ionicons name="exit" size={20} color="#C70039" />
  <Text style={[styles.buttonText, styles.secondaryButtonText]}>SAIR DA CONTA</Text>
</TouchableOpacity>
      </View>

      {showSuccess && (
        <Animated.View style={[styles.successOverlay, { transform: [{ scale: successScale }] }]}>
          <Ionicons name="checkmark-circle" size={100} color="#2E7D32" />
          <Text style={[styles.profileTitle, { color: '#2E7D32', marginTop: 10 }]}>
            Perfil Atualizado!
          </Text>
        </Animated.View>
      )}
    </SafeAreaView>
  );
}



// ── Navigator ─────────────────────────────────────────────────────────────────

export default function ProfessorPage({ route }) {
  return (
    <Stack.Navigator
      initialRouteName="AlunosList"
      screenOptions={{
        headerStyle: { backgroundColor: '#fff', elevation: 0, shadowOpacity: 0 },
        headerTintColor: '#C70039',
        headerTitleStyle: { fontWeight: 'bold', fontSize: 20 }
      }}
    >
      <Stack.Screen
        name="AlunosList"
        component={AlunosListScreen}
        initialParams={route.params}
        options={({ navigation }) => ({
          title: 'Meus Alunos',
          headerBackVisible: false, 
          headerLeft: () => null,
          headerRight: () => (
            <TouchableOpacity
              onPress={() =>
                navigation.navigate('ConfigScreen', { usuario: route.params.usuario })
              }
              style={{ marginRight: 15 }}
            >
              <Ionicons name="settings" size={26} color="#C70039" />
            </TouchableOpacity>
          )
        })}
      />
     <Stack.Screen
      name="AlunoDetalhes"
      component={AlunoDetalhesScreen}
      options={{
        headerShown: false,
      }}
    />
      <Stack.Screen
  name="ConfigScreen"
  component={ConfigScreen}
  options={{
    headerShown: false // Isso remove totalmente a barra superior
  }}
/>
    </Stack.Navigator>
  );
}

