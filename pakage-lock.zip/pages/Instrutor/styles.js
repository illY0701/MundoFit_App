import { StyleSheet, Dimensions } from 'react-native';
import { Platform, StatusBar } from 'react-native';
const { width } = Dimensions.get('window');

export default StyleSheet.create({
  // ─────────────── GERAL ───────────────
  container: { flex: 1, backgroundColor: '#fff' },
  loader: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  // ─────────────── LISTA DE ALUNOS ───────────────
  searchInput: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#FFC1C1',
    marginHorizontal: 16,
    marginVertical: 10,
    paddingHorizontal: 12,
    padding: 10,
  },
  card: { marginHorizontal: 16, marginBottom: 10 },
  cardInner: { padding: 15, borderRadius: 8 },
  cardTitle: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  cardText: { color: '#FFD1DC', fontSize: 14 },

  // ─────────────── DETALHES DO ALUNO ───────────────
  alunoHeader: {
    padding: 20,
    paddingBottom: 25,
    marginBottom: 16,
    paddingTop: Platform.OS === 'ios' ? 45 : 25,
  },
  headerWrapper: {
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
  },
  alunoNome: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center'
  },
  alunoInfo: {
    color: '#FFD1DC',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 5
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    marginBottom: 16
  },
  actionButton: {
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 5
  },
  treinoCard: {
    backgroundColor: '#FFE5E5',
    borderRadius: 8,
    padding: 15,
    marginHorizontal: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#FFC1C1'
  },
  treinoHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8
  },
  treinoTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#900C3F',
    flex: 1
  },
  treinoActions: {
    flexDirection: 'row',
    gap: 15
  },
  treinoText: {
    color: '#690202',
    marginBottom: 5
  },
  treinoDate: {
    color: '#666',
    fontSize: 12,
    marginTop: 5
  },
  emptyText: {
    textAlign: 'center',
    marginTop: 20,
    color: '#666',
    fontSize: 16
  },

  // ─────────────── CONFIGURAÇÕES DO PROFESSOR ───────────────
  configContainer: {
    flex: 1,
    backgroundColor: '#FFF9F9',
    paddingHorizontal: 20,
    paddingTop: 15,
  },

  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 25,
    borderBottomWidth: 1,
    borderBottomColor: '#FFE5E5',
    marginBottom: 25,
    marginTop: 10,
  },
  profileIcon: {
    backgroundColor: '#C70039',
    width: 70,
    height: 70,
    borderRadius: 35,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 20,
  },
  profileTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#690202',
    letterSpacing: -0.5,
  },
  profileSubtitle: {
    color: '#C70039',
    fontSize: 14,
    marginTop: 4,
  },
  inputContainer: {
    marginBottom: 25,
  },
  inputLabel: {
    color: '#C70039',
    fontSize: 13,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 1.2,
    marginBottom: 10,
    marginLeft: 5,
  },
  inputField: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 18,
    fontSize: 16,
    color: '#690202',
    borderWidth: 1.5,
    borderColor: '#FFE5E5',
    shadowColor: '#69020220',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 5,
  },
  readonlyField: {
    backgroundColor: '#FFF5F5',
    borderColor: '#FFD1DC',
    color: '#900C3F',
  },
  buttonGroup: {
    marginTop: 35,
    gap: 15,
  },
  primaryButton: {
    backgroundColor: '#C70039',
    borderRadius: 14,
    paddingVertical: 18,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
    shadowColor: '#690202',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  secondaryButton: {
    backgroundColor: '#FFF5F5',
    borderWidth: 2,
    borderColor: '#C70039',
  },
  buttonText: {
    color: '#FFF5F5',
    fontWeight: '700',
    fontSize: 15,
    marginLeft: 10,
    letterSpacing: 0.8,
  },
  secondaryButtonText: {
  color: '#C70039',
},
  successOverlay: {
    position: 'absolute',
    top: '30%',
    left: 0,
    right: 0,
    alignItems: 'center',
    zIndex: 1,
    backgroundColor: '#FFFFFFEE',
    justifyContent: 'center',
    padding: 20,
    borderRadius: 16,
  },
  successText: {
    color: '#2E7D32',
    fontSize: 20,
    fontWeight: '700',
    marginTop: 10,
  },

  // ─────────────── MODAL DE TREINO ───────────────
  modalContainer: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff'
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#C70039'
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#900C3F',
    marginBottom: 8
  },
  exerciseList: { marginBottom: 10, maxHeight: 200 },
  exerciseOption: {
    padding: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#C70039',
    marginBottom: 6,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  selectedExercise: { backgroundColor: '#C70039' },
  exerciseText: { color: '#690202' },
  customExerciseContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12
  },
  addButton: {
    backgroundColor: '#C70039',
    borderRadius: 8,
    padding: 8,
    marginLeft: 8
  },
  customExercisesSelected: {
    marginBottom: 12
  },
  customExerciseItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#FFE5E5',
    padding: 10,
    borderRadius: 8,
    marginBottom: 6
  },

  // ─────────────── MODAL DE CONFIRMAÇÃO ───────────────
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)'
  },
  modalView: {
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 20,
    width: '80%'
  },
  modalText: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: 'center'
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  modalButton: {
    flex: 1,
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginHorizontal: 5
  },

  // ─────────────── BOTÕES DE DIAS DA SEMANA ───────────────
  daysScroll: {
    marginVertical: 10,
    height: 50,
    marginBottom: 25,
  },
  dayButton: {
    backgroundColor: '#FFE5E5',
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 20,
    marginHorizontal: 5,
    borderWidth: 1,
    borderColor: '#FFC1C1',
    justifyContent: 'center',
    height: 40,
  },
  dayButtonText: {
    color: '#690202',
    fontWeight: '500',
    fontSize: 14,
    includeFontPadding: false,
    textAlign: 'center'
  },
  selectedDayButton: {
    backgroundColor: '#C70039',
    borderColor: '#690202'
  },
  selectedDayText: {
    color: 'white'
  },
});