import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { useSharedValue, withSpring } from 'react-native-reanimated';

import { api } from '../utils/api';

const Cadastro = ({ navigation }) => {
  const [nm_aluno, setNome] = useState('');
  const [email_aluno, setEmail] = useState('');
  const [cd_senha_al, setSenha] = useState('');
  const [confirmSenha, setConfirmSenha] = useState('');
  const [cd_peso, setPeso] = useState('');
  const [cd_altura, setAltura] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const buttonScale = useSharedValue(1);
  const buttonOpacity = useSharedValue(1);

  const handlePressIn = () => {
    buttonScale.value = withSpring(0.97);
    buttonOpacity.value = withSpring(0.9);
  };

  const handlePressOut = () => {
    buttonScale.value = withSpring(1);
    buttonOpacity.value = withSpring(1);
  };

  const handleCadastro = async () => {
    if (!nm_aluno || !email_aluno || !cd_senha_al || !confirmSenha || !cd_peso || !cd_altura) {
      Alert.alert('Erro', 'Preencha todos os campos');
      return;
    }

    if (cd_senha_al !== confirmSenha) {
      Alert.alert('Erro', 'As senhas não coincidem');
      return;
    }

    if (isNaN(cd_peso) || isNaN(cd_altura)) {
      Alert.alert('Erro', 'Peso e altura devem ser números válidos');
      return;
    }

    try {
      const response = await fetch(`${api}/alunos`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          nm_aluno,
          email_aluno,
          cd_senha_al,
          cd_peso: Number(cd_peso),
          cd_altura: Number(cd_altura)
        }),
      });

      const responseData = await response.json();

      if (!response.ok) {
        throw new Error(responseData.error || 'Erro no cadastro');
      }

      Alert.alert('Sucesso', 'Cadastro realizado com sucesso!');
      navigation.navigate('Login');
      
    } catch (error) {
      console.error('Erro no cadastro:', error);
      Alert.alert('Erro', error.message || 'Erro ao conectar com o servidor');
    }
  };

  return (
    <LinearGradient colors={['#C70039', '#900C3F']} style={styles.container}>
      <Text style={styles.title}>Cadastro</Text>

      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Nome completo"
          style={styles.input}
          value={nm_aluno}
          onChangeText={setNome}
          placeholderTextColor="rgba(255,255,255,0.7)"
          autoCapitalize="words"
        />
      </View>

      <View style={styles.inputContainer}>
        <TextInput
          placeholder="E-mail"
          style={styles.input}
          value={email_aluno}
          onChangeText={setEmail}
          keyboardType="email-address"
          placeholderTextColor="rgba(255,255,255,0.7)"
          autoCapitalize="none"
        />
      </View>

      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Senha"
          style={styles.input}
          value={cd_senha_al}
          onChangeText={setSenha}
          secureTextEntry={!showPassword}
          placeholderTextColor="rgba(255,255,255,0.7)"
        />
        <TouchableOpacity 
          style={styles.eyeButton}
          onPress={() => setShowPassword(!showPassword)}
        >
          <View style={[styles.eyeIcon, !showPassword && styles.eyeIconClosed]}>
            <View style={styles.eyeLine}></View>
          </View>
        </TouchableOpacity>
      </View>

      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Confirmar Senha"
          style={styles.input}
          value={confirmSenha}
          onChangeText={setConfirmSenha}
          secureTextEntry={!showConfirmPassword}
          placeholderTextColor="rgba(255,255,255,0.7)"
        />
        <TouchableOpacity 
          style={styles.eyeButton}
          onPress={() => setShowConfirmPassword(!showConfirmPassword)}
        >
          <View style={[styles.eyeIcon, !showConfirmPassword && styles.eyeIconClosed]}>
            <View style={styles.eyeLine}></View>
          </View>
        </TouchableOpacity>
      </View>

      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Peso (kg)"
          style={styles.input}
          value={cd_peso}
          onChangeText={setPeso}
          keyboardType="numeric"
          placeholderTextColor="rgba(255,255,255,0.7)"
        />
      </View>

      <View style={styles.inputContainer}>
        <TextInput
          placeholder="Altura (cm)"
          style={styles.input}
          value={cd_altura}
          onChangeText={setAltura}
          keyboardType="numeric"
          placeholderTextColor="rgba(255,255,255,0.7)"
        />
      </View>

      <Animated.View style={{ 
        transform: [{ scale: buttonScale }], 
        opacity: buttonOpacity 
      }}>
        <TouchableOpacity
          style={styles.button}
          onPress={handleCadastro}
          onPressIn={handlePressIn}
          onPressOut={handlePressOut}
          activeOpacity={0.9}
        >
          <Text style={styles.buttonText}>Cadastrar</Text>
        </TouchableOpacity>
      </Animated.View>

      <TouchableOpacity onPress={() => navigation.navigate('Login')}>
        <Text style={styles.linkText}>Já tem uma conta? Faça login</Text>
      </TouchableOpacity>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 30,
  },
  title: {
    fontSize: 32,
    color: '#FFF',
    marginBottom: 40,
    fontWeight: '600',
    letterSpacing: 1,
  },
  inputContainer: {
    width: '100%',
    marginBottom: 20,
    position: 'relative',
  },
  input: {
    width: '100%',
    height: 50,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 10,
    paddingHorizontal: 20,
    color: '#FFF',
    fontSize: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  button: {
    backgroundColor: '#5A0828',
    width: 200,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 30,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 5,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: '600',
    letterSpacing: 1,
  },
  linkText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    marginTop: 25,
    textDecorationLine: 'underline',
  },
  eyeButton: {
    position: 'absolute',
    right: 15,
    top: 13,
    padding: 5,
  },
  eyeIcon: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  eyeIconClosed: {
    borderColor: 'rgba(255,255,255,0.4)',
  },
  eyeLine: {
    width: 12,
    height: 2,
    backgroundColor: 'rgba(255,255,255,0.7)',
    transform: [{ rotate: '-45deg' }],
    position: 'absolute',
  },
});

export default Cadastro;