import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { useSharedValue, withSpring } from 'react-native-reanimated';
import { api } from '../utils/api';

const Login = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const buttonScale = useSharedValue(1);
  const buttonOpacity = useSharedValue(1);

  const handlePressIn = () => {
    buttonScale.value = withSpring(0.97);
    buttonOpacity.value = withSpring(0.9);
  };

  const handlePressOut = () => {
    buttonScale.value = withSpring(1);
    buttonOpacity.value = withSpring(1);
  };

  const handleLogin = async () => {
    try {
      const response = await fetch(`${api}/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, senha }),
      });

      const data = await response.json();

      if (response.ok) {
        switch(data.tipoUsuario) {
          case 'admin':
            navigation.navigate('AdminPage', { 
              usuario: { id: data.id, nome: data.nome }
            });
            break;
          case 'professor':
            navigation.navigate('ProfessorPage', { 
              usuario: {
                id: data.id,
                nm_professor: data.nome,
                ds_especialidade: data.especialidade
              }
            });
            break;
          case 'aluno':
            navigation.navigate('AlunoPage', { 
              usuario: {
                id: data.id,
                nm_aluno: data.nm_aluno,
                cd_peso: data.peso,
                cd_altura: data.altura
              }
            });
            break;
          default:
            Alert.alert('Erro', 'Tipo de usuário desconhecido');
        }
      } else {
        Alert.alert('Erro', data.mensagem || 'Credenciais inválidas');
      }
    } catch (error) {
      Alert.alert('Erro', 'Erro ao conectar com o servidor');
    }
  };

  return (
    <LinearGradient colors={['#C70039', '#900C3F']} style={styles.container}>
      <Text style={styles.title}>Login</Text>

      <View style={styles.inputContainer}>
        <TextInput 
          placeholder="E-mail" 
          style={styles.input} 
          value={email} 
          onChangeText={setEmail}
          placeholderTextColor="rgba(255,255,255,0.7)"
          autoCapitalize="none"
          keyboardType="email-address"
        />
      </View>

      <View style={styles.inputContainer}>
        <TextInput 
          placeholder="Senha" 
          style={styles.input} 
          value={senha} 
          onChangeText={setSenha}
          placeholderTextColor="rgba(255,255,255,0.7)"
          secureTextEntry={!showPassword}
        />
        <TouchableOpacity 
          style={styles.eyeButton}
          onPress={() => setShowPassword(!showPassword)}
        >
          <View style={[styles.eyeIcon, !showPassword && styles.eyeIconClosed]}>
            <View style={styles.eyeLine}></View>
          </View>
        </TouchableOpacity>
      </View>

      <Animated.View style={{ 
        transform: [{ scale: buttonScale }], 
        opacity: buttonOpacity 
      }}>
        <TouchableOpacity
          style={styles.button}
          onPress={handleLogin}
          onPressIn={handlePressIn}
          onPressOut={handlePressOut}
          activeOpacity={0.9}
        >
          <Text style={styles.buttonText}>Entrar</Text>
        </TouchableOpacity>
      </Animated.View>

      <TouchableOpacity onPress={() => navigation.navigate('Cadastro')}>
        <Text style={styles.linkText}>Não tem conta? Cadastre-se</Text>
      </TouchableOpacity>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 30,
  },
  title: {
    fontSize: 32,
    color: '#FFF',
    marginBottom: 40,
    fontWeight: '600',
    letterSpacing: 1,
  },
  inputContainer: {
    width: '100%',
    marginBottom: 20,
    position: 'relative',
  },
  input: {
    width: '100%',
    height: 50,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 10,
    paddingHorizontal: 20,
    color: '#FFF',
    fontSize: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  button: {
    backgroundColor: '#5A0828',
    width: 200,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 30,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 5,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: '600',
    letterSpacing: 1,
  },
  linkText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    marginTop: 25,
    textDecorationLine: 'underline',
  },
  eyeButton: {
    position: 'absolute',
    right: 15,
    top: 13,
    padding: 5,
  },
  eyeIcon: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  eyeIconClosed: {
    borderColor: 'rgba(255,255,255,0.4)',
  },
  eyeLine: {
    width: 12,
    height: 2,
    backgroundColor: 'rgba(255,255,255,0.7)',
    transform: [{ rotate: '-45deg' }],
    position: 'absolute',
  },
});

export default Login;