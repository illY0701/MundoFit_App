import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, TouchableOpacity, FlatList, StyleSheet,
  ActivityIndicator, ScrollView, TextInput, Dimensions,
  Alert, Animated, Modal, RefreshControl
} from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useIsFocused } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import { BarChart } from 'react-native-chart-kit';
import { api } from '../utils/api';
import styles from './styles';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { SafeAreaView } from 'react-native';
import TreinoDetalhes from './TreinoDetalhes'


const Tab = createBottomTabNavigator();
const { width } = Dimensions.get('window');

// ── Helpers ───────────────────────────────────────────────────────────────────

function Loading() {
  return (
    <View style={styles.center}>
      <ActivityIndicator size="large" color="#C70039" />
    </View>
  );
}

function Message({ text, color }) {
  return (
    <View style={styles.center}>
      <Text style={{ color }}>{text}</Text>
    </View>
  );
}

// ── Calendar ──────────────────────────────────────────────────────────────────

function Calendar({ week, selected, onToggle }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.calendarScroll}>
      <View style={styles.calendarContainer}>
        {week.map(date => {
          const key = date.toISOString().split('T')[0];
          const sel = !!selected[key];
          const weekDay = date.toLocaleDateString('pt-BR', { weekday: 'short' });
          const day = date.getDate();
          return (
            <TouchableOpacity
              key={key}
              onPress={() => onToggle(key)}
              style={[styles.dayContainer, sel && styles.selectedDay]}
            >
              <Text style={[styles.weekDayText, sel && styles.selectedDayText]}> {weekDay} </Text>
              <Text style={[styles.dayText, sel && styles.selectedDayText]}> {day} </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </ScrollView>
  );
}

// ── MainScreen ────────────────────────────────────────────────────────────────

function MainScreen({ route, navigation }) {
  const aluno = route.params.aluno || route.params.usuario || {};
  const [treinos, setTreinos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDates, setSelectedDates] = useState({});
  const [currentWeek, setCurrentWeek] = useState([]);

  useEffect(() => {
    const days = [];
    const today = new Date();
    for (let i = 0; i < 7; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() + i);
      days.push(d);
    }
    setCurrentWeek(days);
  }, []);

  const saveHistorico = async (dateKey, peso) => {
    try {
      const body = { cd_fk_aluno: aluno.id, cd_fk_treino: null, dt_treino_realizado: dateKey, cd_fk_peso: Number(peso), ds_comentarios: '' };
      const res = await fetch(`${api}/historicos`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Erro');
      }
      setSelectedDates(prev => ({ ...prev, [dateKey]: true }));
    } catch (e) {
      Alert.alert('Erro ao registrar', e.message);
    }
  };

  const toggleDate = key => {
    if (!selectedDates[key]) {
      Alert.prompt(
        'Registrar Evolução',
        `Peso em ${key}:`,
        [ { text: 'Cancelar', style: 'cancel' }, { text: 'OK', onPress: peso => saveHistorico(key, peso) } ],
        'plain-text'
      );
    } else {
      setSelectedDates(prev => ({ ...prev, [key]: false }));
    }
  };

  const fetchTreinos = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${api}/treinos`);
      const json = await res.json();
      const meus = json.filter(t => String(t.cd_fk_aluno) === String(aluno.id));
      const agrupados = Object.values(meus.reduce((acc, cur) => {
        if (!acc[cur.nm_treino]) acc[cur.nm_treino] = cur;
        return acc;
      }, {}));
      setTreinos(agrupados);
    } catch {
      Alert.alert('Erro', 'Não foi possível carregar treinos');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (aluno.id) fetchTreinos(); else setLoading(false);
  }, [aluno.id]);

  if (loading) return <Loading />;
  if (!aluno.id) return <Message text="Aluno não identificado." color="#C70039" />;

  return (
    <LinearGradient colors={['#fff', '#fff']} style={styles.container}>
      <StatusBar style="dark" />
      <Text style={styles.sectionWelcome}>Bem-vindo(a), {aluno.nm_aluno}</Text>
      <Calendar week={currentWeek} selected={selectedDates} onToggle={toggleDate} />
      <Text style={styles.sectionTitle}>SEUS TREINOS ATIVOS</Text>
      <FlatList
        data={treinos}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <TreinoCard item={item} nav={navigation} />}
        contentContainerStyle={{ paddingBottom: 20 }}
      />
    </LinearGradient>
  );
}

function TreinoCard({ item, nav }) {
  const dateObj = new Date(item.dt_treino);
  return (
    <TouchableOpacity onPress={() => nav.navigate('TreinoDetails', { treino: item })} activeOpacity={0.8}>
      <LinearGradient colors={['rgba(199,0,57,1)', 'rgba(144,12,63,1)']} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={styles.card}>
        <Text style={styles.cardTitle}>{item.nm_treino}</Text>
        <Text style={styles.cardText}>Objetivo: {item.ds_objetivo}</Text>
        <Text style={styles.cardDate}>{dateObj.toLocaleDateString()}</Text>
      </LinearGradient>
    </TouchableOpacity>
  );
}


// ── TreinoScreen ─────────────────────────────────────────────────────────
function TreinoScreen({ route, navigation }) {
  const aluno = route.params.aluno || route.params.usuario || {};
  const [treinos, setTreinos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDay, setSelectedDay] = useState(null);

  const diasSemana = [
    'Segunda-feira',
    'Terça-feira',
    'Quarta-feira',
    'Quinta-feira',
    'Sexta-feira',
    'Sábado',
    'Domingo'
  ];

  const fetchTreinos = async () => {
  setLoading(true);
  try {
    if (!aluno?.id) {
      console.log('Erro: Aluno não identificado');
      Alert.alert('Erro', 'Aluno não identificado');
      return;
    }

    console.log('Buscando treinos para o aluno:', aluno.id);
    const res = await fetch(`${api}/treinos?idAluno=${aluno.id}`);

    if (!res.ok) {
      console.log('Erro na resposta da API:', res.status, res.statusText);
      throw new Error('Erro ao buscar treinos');
    }

    const json = await res.json();
    console.log('Dados recebidos da API:', json);

    // Filtrar treinos pelo cd_fk_aluno
    const treinosFiltrados = json.filter(treino => {
      // Convertendo ambos para lowercase para evitar problemas de case sensitivity
      const treinoIdAluno = treino.cd_fk_aluno?.toLowerCase();
      const alunoId = aluno.id?.toLowerCase();
      
      console.log(`Comparando treino.cd_fk_aluno: ${treinoIdAluno} com aluno.id: ${alunoId}`);
      
      return treinoIdAluno === alunoId;
    });

    console.log('Treinos filtrados:', treinosFiltrados);

    if (treinosFiltrados.length === 0) {
      console.log('Nenhum treino encontrado para o aluno');
      Alert.alert('Informação', 'Nenhum treino encontrado');
      setTreinos([]);
      return;
    }

    // Agrupar treinos por ID único
    const treinosAgrupados = treinosFiltrados.reduce((acc, current) => {
      const treinoId = current.cd_treino; // Supondo que cd_treino é o ID único do treino
      
      // Se o treino não existe, cria um novo
      if (!acc[treinoId]) {
        acc[treinoId] = {
          id: treinoId,
          nm_treino: current.nm_treino,
          diaSemana: current.diaSemana,
          ds_objetivo: current.ds_objetivo,
          dt_treino: current.dt_treino,
          dataFormatada: new Date(current.dt_treino).toLocaleDateString('pt-BR'),
          exercicios: []
        };
      }

      // Adiciona exercício se for válido e não existir
      if (current.cd_fk_exercicio && current.nm_fk_exercicio) {
        const exercicioExiste = acc[treinoId].exercicios.some(
          ex => ex.id === current.cd_fk_exercicio
        );

        if (!exercicioExiste) {
          acc[treinoId].exercicios.push({
            id: current.cd_fk_exercicio,
            nome: current.nm_fk_exercicio
          });
        }
      }

      return acc;
    }, {});

    console.log('Treinos agrupados:', treinosAgrupados);
    setTreinos(Object.values(treinosAgrupados));

  } catch (error) {
    console.error('Erro ao buscar treinos:', error);
    Alert.alert('Erro', 'Não foi possível carregar treinos');
  } finally {
    setLoading(false);
  }
};


  useEffect(() => {
    if (aluno.id) fetchTreinos();
    else setLoading(false);
  }, [aluno.id]);

  const filteredTreinos = () => {
    return treinos.filter(t => {
      const matchesSearch =
        t.nm_treino.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.ds_objetivo.toLowerCase().includes(searchTerm.toLowerCase());

      const normalizedSelected = selectedDay?.replace(/-feira/gi, '')?.trim()?.toLowerCase();
      const normalizedTreinoDay = t.diaSemana?.toLowerCase();

      return matchesSearch && (!selectedDay || normalizedTreinoDay === normalizedSelected);
    });
  };

  if (loading) return <Loading />;

  return (
    <LinearGradient colors={['#FFFFFF', '#FFF0F5']} style={styles.container}>
      <Text style={styles.screenTitle}>Treinos{aluno.nm_aluno}</Text>

      {/* Barra de Busca */}
      <View style={styles.searchContainer}>
        <Ionicons name="search-outline" size={20} color="#C70039" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Buscar treino..."
          placeholderTextColor="#999"
          value={searchTerm}
          onChangeText={setSearchTerm}
        />
      </View>

      {/* Filtro de Dias */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.daysScroll}
      >
        {diasSemana.map(dia => {
          const displayName = dia.replace('-feira', '');
          const normalizedDay = displayName.trim().toLowerCase();

          return (
            <TouchableOpacity
              key={dia}
              style={[
                styles.dayButton,
                selectedDay?.toLowerCase() === normalizedDay && styles.selectedDayButton
              ]}
              onPress={() =>
                setSelectedDay(prev =>
                  prev?.toLowerCase() === normalizedDay ? null : displayName
                )
              }
            >
              <Text
                style={[
                  styles.dayButtonText,
                  selectedDay?.toLowerCase() === normalizedDay && styles.selectedDayButtonText
                ]}
              >
                {displayName.slice(0, 3)}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>



     {/* Lista de Treinos */}
      <FlatList
        data={filteredTreinos()}
        keyExtractor={(item, index) => `${item.id}-${index}`}
        renderItem={({ item }) => (
          <TouchableOpacity 
            onPress={() => navigation.navigate('TreinoDetalhes', { treino: item })}
            activeOpacity={0.9}
          >
            <LinearGradient
              colors={['#FFE5E5', '#FFFFFF']}
              style={styles.treinoCard}
              start={{ x: 0.5, y: 0 }}
              end={{ x: 0.5, y: 1 }}
            >
              <View style={styles.treinoHeader}>
                <Text style={styles.treinoName}>{item.nm_treino}</Text>
                <View style={styles.treinoMeta}>
                  <Text style={styles.treinoDay}>{item.diaSemana}</Text>
                  <Text style={styles.treinoDate}>{item.dataFormatada}</Text>
                </View>
              </View>

              <Text style={styles.treinoObjective}>{item.ds_objetivo}</Text>

              <View style={styles.exerciciosContainer}>
                {item.exercicios.map((ex, index) => (
                  <View key={`${ex.id}-${index}`} style={styles.exerciseItem}>
                    <Ionicons name="barbell-outline" size={16} color="#C70039" />
                    <Text style={styles.exerciseText}>{ex.nome}</Text>
                  </View>
                ))}
              </View>
            </LinearGradient>
          </TouchableOpacity>
        )}
        contentContainerStyle={{ paddingBottom: 20 }}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Ionicons name="sad-outline" size={50} color="#C70039" />
            <Text style={styles.emptyText}>Nenhum treino encontrado</Text>
          </View>
        }
      />
    </LinearGradient>
  );
}

// ── DesempenhoScreen ─────────────────────────────────────────────────────────

function DesempenhoScreen({ route }) {
  const aluno = route.params.aluno || route.params.usuario || {};
  const isFocused = useIsFocused();
  const [hist, setHist] = useState([]);
  const [perfil, setPerfil] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalMetaVisible, setModalMetaVisible] = useState(false);
  const [peso, setPeso] = useState('');
  const [pesoMeta, setPesoMeta] = useState('');
  const [comentario, setComentario] = useState('');

  const fetchHist = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${api}/historicos?alunoId=${aluno.id}`);
      const data = await res.json();

      const filteredHist = data.filter(item => 
        item.cd_fk_peso && 
        !item.cd_fk_treino &&
        item.dt_treino_realizado
      );

      filteredHist.sort((a, b) => new Date(a.dt_treino_realizado) - new Date(b.dt_treino_realizado));
      setHist(filteredHist);
    } catch {
      Alert.alert('Erro', 'Não foi possível carregar histórico');
    } finally {
      setLoading(false);
    }
  };

  const fetchPerfil = async () => {
    try {
      const r = await fetch(`${api}/alunos/${aluno.id}`);
      const data = await r.json();
      setPerfil(data);
      setPesoMeta(data.peso_meta?.toString() || '');
    } catch {}
  };

  useEffect(() => {
    if (isFocused && aluno.id) { 
      fetchHist(); 
      fetchPerfil(); 
    }
  }, [isFocused, aluno.id]);

  const onRefresh = async () => { 
    setRefreshing(true); 
    await fetchHist(); 
    setRefreshing(false); 
  };

  const submitDesempenho = async () => {
    if (!peso) {
      Alert.alert('Erro', 'Informe o peso atual');
      return;
    }

    try {
      const todayKey = new Date().toISOString().split('T')[0];
      const body = { 
        cd_fk_aluno: aluno.id, 
        cd_fk_treino: null, 
        dt_treino_realizado: todayKey, 
        cd_fk_peso: Number(peso), 
        ds_comentarios: comentario 
      };

      const res = await fetch(`${api}/historicos`, { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/json' }, 
        body: JSON.stringify(body) 
      });

      if (!res.ok) throw new Error('Falha no servidor');

      setModalVisible(false);
      setPeso(''); 
      setComentario('');
      await fetchHist();
    } catch (e) { 
      Alert.alert('Erro ao registrar', e.message); 
    }
  };

  const savePesoMeta = async () => {
    if (!pesoMeta) return;

    try {
      const res = await fetch(`${api}/alunos/${aluno.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...perfil, peso_meta: Number(pesoMeta) })
      });

      if (!res.ok) throw new Error();
      await fetchPerfil();
    } catch {
      Alert.alert('Erro', 'Falha ao salvar peso meta');
    }
  };

  if (loading) return null;

  const initialWeight = hist[0]?.cd_fk_peso || '-';
  const currentWeight = hist[hist.length - 1]?.cd_fk_peso || '-';
  const altura = perfil?.cd_fk_altura ? perfil.cd_fk_altura / 100 : null;
  const bmi = altura && currentWeight !== '-' 
    ? (currentWeight / (altura * altura)).toFixed(1)
    : '-';

  const labels = hist.map(h => 
    new Date(h.dt_treino_realizado).toLocaleDateString('pt-BR', { 
      day: '2-digit', 
      month: '2-digit' 
    })
  );
  const data = hist.map(h => Number(h.cd_fk_peso));

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        contentContainerStyle={styles.dashboardContainer}
      >
        <View style={styles.performanceHeader}>
          <Text style={styles.headerTitle}>Evolução Física</Text>
          <Text style={styles.headerSubtitle}>Acompanhe seu progresso detalhadamente</Text>
        </View>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{initialWeight}</Text>
            <Text style={styles.statLabel}>Peso Inicial</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{currentWeight}</Text>
            <Text style={styles.statLabel}>Peso Atual</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{bmi}</Text>
            <Text style={styles.statLabel}>Índice IMC</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{pesoMeta || '-'}</Text>
            <Text style={styles.statLabel}>Meta Definida</Text>
          </View>
        </View>

        <TouchableOpacity
          style={styles.recordButton}
          onPress={() => setModalMetaVisible(true)}
        >
          <Ionicons name="flag" size={20} color="#FFF5F5" />
          <Text style={styles.recordButtonText}>Definir Meta de Peso</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.recordButton}
          onPress={() => setModalVisible(true)}
        >
          <Ionicons name="fitness" size={20} color="#FFF5F5" />
          <Text style={styles.recordButtonText}>Registrar Nova Medição</Text>
        </TouchableOpacity>

        {data.length > 0 ? (
          <View style={styles.chartContainer}>
            <Text style={styles.chartTitle}>Histórico de Progresso</Text>
            <BarChart
              data={{ labels, datasets: [{ data }] }}
              width={width * 0.85}
              height={220}
              yAxisSuffix=" kg"
              fromZero
              chartConfig={{
                backgroundGradientFrom: '#FFF5F5',
                backgroundGradientTo: '#FFF5F5',
                decimalPlaces: 1,
                barPercentage: 0.5,
                color: () => '#C70039',
                labelColor: () => '#690202',
                propsForLabels: { fontSize: 10 }
              }}
            />
          </View>
        ) : (
          <View style={styles.emptyState}>
            <Ionicons name="stats-chart" size={40} color="#C70039" />
            <Text style={styles.emptyText}>Comece registrando suas primeiras medições!</Text>
          </View>
        )}

        {/* Modal Registrar Medição */}
        <Modal animationType="fade" transparent visible={modalVisible}>
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Registro de Medição</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="Peso atual em kg"
                placeholderTextColor="#900C3F"
                keyboardType="numeric"
                value={peso}
                onChangeText={setPeso}
              />
              <TextInput
                style={[styles.modalInput, { height: 80 }]}
                placeholder="Anotações (opcional)"
                placeholderTextColor="#900C3F"
                multiline
                value={comentario}
                onChangeText={setComentario}
              />
              <View style={styles.modalActions}>
                <TouchableOpacity
                  style={[styles.modalButton, { backgroundColor: '#FFE5E5' }]}
                  onPress={() => setModalVisible(false)}
                >
                  <Text style={[styles.modalButtonText, { color: '#C70039' }]}>Cancelar</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.modalButton}
                  onPress={submitDesempenho}
                >
                  <Text style={styles.modalButtonText}>Salvar</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>

        {/* Modal Meta de Peso */}
        <Modal animationType="fade" transparent visible={modalMetaVisible}>
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Definir Meta de Peso</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="Meta de peso em kg"
                placeholderTextColor="#900C3F"
                keyboardType="numeric"
                value={pesoMeta}
                onChangeText={setPesoMeta}
              />
              <View style={styles.modalActions}>
                <TouchableOpacity
                  style={[styles.modalButton, { backgroundColor: '#FFE5E5' }]}
                  onPress={() => setModalMetaVisible(false)}
                >
                  <Text style={[styles.modalButtonText, { color: '#C70039' }]}>Cancelar</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.modalButton}
                  onPress={async () => {
                    await savePesoMeta();
                    setModalMetaVisible(false);
                  }}
                >
                  <Text style={styles.modalButtonText}>Salvar</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>

      </ScrollView>
    </SafeAreaView>
  );
}


// ── PerfilScreen ──────────────────────────────────────────────────────────────

function PerfilScreen({ route, navigation }) {
  const aluno = route.params.aluno || route.params.usuario || {};
  const isFocused = useIsFocused();
  const [dados, setDados] = useState(null);
  const [edit, setEdit] = useState(false);
  const [loading, setLoading] = useState(true);
  const [show, setShow] = useState(false);
  const scale = useRef(new Animated.Value(0)).current;

  const fetchPerfil = async () => {
    setLoading(true);
    try {
      const r = await fetch(`${api}/alunos/${aluno.id}`);
      const data = await r.json();
      
      // Normalização dos dados recebidos
      setDados({
        ...data,
        // Garantir que os campos numéricos estão tratados
        cd_peso: data.cd_peso || 0,
        cd_altura: data.cd_altura || 0,
        nm_aluno: data.nm_aluno || ''
      });
      
    } catch {
      Alert.alert('Erro', 'Não foi possível carregar perfil');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { 
    if (isFocused && aluno.id) fetchPerfil(); 
  }, [isFocused, aluno.id]);

  const handleUpdate = async () => {
    if (!dados.nm_aluno || !dados.cd_peso || !dados.cd_altura) {
      return Alert.alert('Erro', 'Preencha todos os campos');
    }
    
    try {
      const res = await fetch(`${api}/alunos/${dados.id}`, { 
        method: 'PUT', 
        headers: { 'Content-Type': 'application/json' }, 
        body: JSON.stringify({
          ...dados,
          cd_peso: Number(dados.cd_peso),
          cd_altura: Number(dados.cd_altura)
        }) 
      });
      
      if (!res.ok) throw new Error();
      
      setEdit(false);
      setShow(true);
      Animated.sequence([
        Animated.timing(scale, { toValue: 1, duration: 300, useNativeDriver: true }),
        Animated.delay(1000),
        Animated.timing(scale, { toValue: 0, duration: 300, useNativeDriver: true })
      ]).start(() => setShow(false));
      
    } catch {
      Alert.alert('Erro', 'Falha ao atualizar perfil');
    }
  };

  const handleLogout = () => {
    // Lógica de logout - ajustar conforme sua implementação
    navigation.reset({
      index: 0,
      routes: [{ name: 'Login' }]
    });
  };

  if (loading) return <Loading />;
  if (!dados) return <Message text="Perfil não encontrado." color="#690202" />;

 return (
     <SafeAreaView style={styles.configContainer}>
      <View style={styles.profileHeader}>
        <View style={styles.profileIcon}>
          <Ionicons name="person-circle" size={42} color="#FFF5F5" />
        </View>
        <View>
          <Text style={styles.profileTitle}>{dados.nm_aluno}</Text>
          <Text style={styles.profileSubtitle}>Perfil do Aluno</Text>
        </View>
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.inputLabel}>Nome completo</Text>
        {edit ? (
          <TextInput
            style={styles.inputField}
            value={dados.nm_aluno}
            onChangeText={t => setDados({ ...dados, nm_aluno: t })}
          />
        ) : (
          <Text style={[styles.inputField, styles.readonlyField]}>{dados.nm_aluno}</Text>
        )}
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.inputLabel}>Peso atual (kg)</Text>
        {edit ? (
          <TextInput
            style={styles.inputField}
            value={dados.cd_peso.toString()}
            keyboardType="numeric"
            onChangeText={t => setDados({ ...dados, cd_peso: t.replace(/[^0-9]/g, '') })}
          />
        ) : (
          <Text style={[styles.inputField, styles.readonlyField]}>{dados.cd_peso} kg</Text>
        )}
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.inputLabel}>Altura (cm)</Text>
        {edit ? (
          <TextInput
            style={styles.inputField}
            value={dados.cd_altura.toString()}
            keyboardType="numeric"
            onChangeText={t => setDados({ ...dados, cd_altura: t.replace(/[^0-9]/g, '') })}
          />
        ) : (
          <Text style={[styles.inputField, styles.readonlyField]}>{dados.cd_altura} cm</Text>
        )}
      </View>

      <View style={styles.buttonGroup}>
        <TouchableOpacity
          style={[styles.primaryButton, edit && { backgroundColor: '#900C3F' }]}
          onPress={edit ? handleUpdate : () => setEdit(true)}
        >
          <Ionicons name={edit ? 'save' : 'create'} size={20} color="#FFF5F5" />
          <Text style={styles.buttonText}>
            {edit ? 'SALVAR ALTERAÇÕES' : 'EDITAR PERFIL'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.primaryButton, styles.secondaryButton]}
          onPress={handleLogout}
        >
          <Ionicons name="exit" size={20} color="#C70039" />
          <Text style={[styles.buttonText, { color: '#C70039' }]}>SAIR DA CONTA</Text>
        </TouchableOpacity>
      </View>

      {show && (
        <Animated.View style={[styles.successOverlay, { transform: [{ scale }] }]}>
          <Ionicons name="checkmark-circle" size={100} color="#2E7D32" />
          <Text style={[styles.profileTitle, { color: '#2E7D32', marginTop: 10 }]}>
            Perfil Atualizado!
          </Text>
        </Animated.View>
      )}
    </SafeAreaView>
  );
}
// ── Field ────────────────────────────────────────────────────────────────────

function Field({ label, edit, value, onChange, keyboardType }) {
  return (
    <>
      <Text style={styles.profileLabel}>{label}:</Text>
      {edit ? (
        <TextInput 
          style={styles.input} 
          value={value} 
          keyboardType={keyboardType} 
          onChangeText={onChange} 
        />
      ) : (
        <Text style={styles.profileText}>{value}</Text>
      )}
    </>
  );
}

// ── Navigator ────────────────────────────────────────────────────────────────
import { createStackNavigator } from '@react-navigation/stack';

const TreinoStack = createStackNavigator();

// Stack Navigator para Treinos
const TreinoStackNavigator = ({ route }) => (
  <TreinoStack.Navigator
    screenOptions={{
      headerShown: false,
      cardStyle: { backgroundColor: '#FFFFFF' }
    }}
  >
    <TreinoStack.Screen 
      name="TreinoList" 
      component={TreinoScreen}
      initialParams={route.params}
    />
    <TreinoStack.Screen 
      name="TreinoDetalhes" 
      component={TreinoDetalhes} 
    />
  </TreinoStack.Navigator>
);

// Componente principal de navegação
function NavigatorWithInsets({ route }) {
  const insets = useSafeAreaInsets();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          const icons = { 
            'Início': 'home', 
            'Treinos': 'barbell', 
            'Desempenho': 'stats-chart', 
            'Perfil': 'person' 
          };
          return <Ionicons name={icons[route.name]} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#690202',
        tabBarInactiveTintColor: '#FFC1C1',
        tabBarStyle: { 
          backgroundColor: '#a60332', 
          borderTopWidth: 0, 
          height: 60 + insets.bottom,
          paddingBottom: insets.bottom,
        },
        headerShown: false
      })}
    >
      <Tab.Screen 
        name="Início" 
        component={MainScreen} 
        initialParams={route.params} 
      />
      
      <Tab.Screen 
        name="Treinos"
      >
        {() => <TreinoStackNavigator route={route} />}
      </Tab.Screen>

      <Tab.Screen 
        name="Desempenho" 
        component={DesempenhoScreen} 
        initialParams={route.params} 
      />
      
      <Tab.Screen 
        name="Perfil" 
        component={PerfilScreen} 
        initialParams={route.params} 
      />
    </Tab.Navigator>
  );
}

// Componente wrapper
export default function AlunoPage({ route }) {
  return (
    <SafeAreaProvider>
      <NavigatorWithInsets route={route} />
    </SafeAreaProvider>
  );
}