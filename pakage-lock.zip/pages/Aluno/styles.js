import { StyleSheet, Dimensions } from 'react-native';
const { width } = Dimensions.get('window');

export default StyleSheet.create({
  // ─────────────── Estilos Gerais ───────────────
  center: { 
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  container: { 
    flex: 1, 
    paddingHorizontal: width * 0.05, 
    paddingTop: 50 
  },

  // ─────────────── Início (MainScreen) ───────────────
  sectionWelcome: { 
    fontSize: 18, 
    fontWeight: 'bold', 
    color: '#C70039', 
    marginBottom: 10 
  },
  sectionTitle: { 
    color: '#C70039', 
    fontSize: 12, 
    marginBottom: 10, 
    alignSelf: 'flex-start' 
  },

  // Calendário semanal
  calendarScroll: { 
    maxHeight: 80 
  },
  calendarContainer: { 
    flexDirection: 'row', 
    marginBottom: 20, 
    paddingHorizontal: 10 
  },
  dayContainer: { 
    backgroundColor: '#FFE5E5', 
    borderRadius: 70, 
    padding: 15, 
    marginHorizontal: 5, 
    alignItems: 'center', 
    width: 58, 
    height: 58, 
    justifyContent: 'center', 
    shadowColor: '#000', 
    shadowOffset: { width: 0, height: 2 }, 
    shadowOpacity: 0.2, 
    shadowRadius: 3, 
    elevation: 4 
  },
  selectedDay: { 
    backgroundColor: '#C70039' 
  },
  weekDayText: { 
    color: '#690202', 
    fontSize: 9, 
    fontWeight: '600', 
    marginBottom: 5 
  },
  dayText: { 
    color: '#690202', 
    fontSize: 11, 
    fontWeight: 'bold' 
  },
  selectedDayText: { 
    color: '#FFF5F5' 
  },

  // Cards de treino do MainScreen
  card: { 
    borderRadius: 12, 
    padding: 15, 
    marginBottom: 12 
  },
  cardTitle: { 
    color: 'white', 
    fontSize: 18, 
    fontWeight: '600' 
  },
  cardText: { 
    color: '#FFD1DC', 
    fontSize: 14, 
    marginTop: 5 
  },
  cardDate: { 
    color: '#FFC1C1', 
    fontSize: 12, 
    marginTop: 8, 
    textAlign: 'right' 
  },

  // ─────────────── Treinos (TreinoScreen) ───────────────
  screenTitle: { 
    color: '#C70039', 
    fontSize: 20, 
    fontWeight: 'bold', 
    marginBottom: 20 
  },

  // Campo de busca
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#FFC1C1',
    paddingHorizontal: 15,
    marginVertical: 10,
    height: 45
  },
  searchIcon: {
    marginRight: 10
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#690202',
    height: '100%',
  },

  // Filtro de dias da semana
  daysScroll: {
    height: 60,
    paddingVertical: 10,
    marginBottom: 8,
  },

  listContainer: {
  flex: 1,
  marginTop: 0, // Garante que não há margem superior
},

  daysContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 5,
    paddingVertical: 10,
    height: 60,
  },
  dayButton: {
    width: 60,
    height: 40,
    backgroundColor: '#FFE5E5',
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 5,
    borderWidth: 1,
    borderColor: '#FFC1C1',
  },
  selectedDayButton: {
    backgroundColor: '#C70039'
  },
  dayButtonText: {
    color: '#690202',
    fontWeight: '500'
  },
  selectedDayButtonText: {
    color: 'white'
  },

  // Card de treino individual
  treinoCard: {
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
    marginHorizontal: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
    marginTop: 0
  },
  treinoHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  treinoName: {
    color: '#C70039',
    fontSize: 18,
    fontWeight: '600',
    flex: 2
  },
  treinoDay: {
    color: '#690202',
    fontSize: 14,
    fontWeight: '500'
  },
  treinoDate: {
    color: '#C70039',
    fontSize: 12,
    marginTop: 4
  },
  treinoObjective: {
    color: '#690202',
    fontSize: 14,
    marginBottom: 15,
    lineHeight: 20
  },
  exerciciosContainer: {
    borderTopWidth: 1,
    borderTopColor: '#FFC1C1',
marginTop: 12, // Espaço interno entre cabeçalho e exercícios
  paddingTop: 12,
  },
  exerciseItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 6,
    paddingVertical: 4
  },
  exerciseText: {
    color: '#690202',
    marginLeft: 10,
    fontSize: 14
  },
  exerciseName: {
    color: '#690202',
    marginLeft: 8,
    fontSize: 14
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20
  },
  emptyText: {
    textAlign: 'center',
    color: '#690202',
    marginTop: 10
  },

  // ─────────────── Desempenho (DesempenhoScreen) ───────────────

  
  performanceHeader: {
    backgroundColor: '#C70039',
    borderRadius: 16,
    padding: 24,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: '800',
    color: '#FFFFFF',
    marginBottom: 8,
    fontFamily: 'Inter-Bold',
  },
  headerSubtitle: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.9)',
    letterSpacing: 0.3,
    fontFamily: 'Inter-Medium',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 16,
    marginBottom: 24,
  },
  statCard: {
    width: '48%',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 3,
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  statValue: {
    fontSize: 28,
    fontWeight: '700',
    color: '#2D3436',
    marginBottom: 4,
    fontFamily: 'Inter-Bold',
  },
  statLabel: {
    fontSize: 12,
    color: '#C70039',
    fontWeight: '600',
    textAlign: 'center',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    fontFamily: 'Inter-SemiBold',
  },
  chartContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginTop: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  chartTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#2D3436',
    marginBottom: 16,
    textAlign: 'center',
    fontFamily: 'Inter-Bold',
  },
  recordButton: {
    backgroundColor: '#C70039',
    borderRadius: 12,
    padding: 18,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
    marginVertical: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  recordButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
    fontFamily: 'Inter-SemiBold',
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.4)',
    padding: 24,
  },
  modalContent: {
    width: '100%',
    maxWidth: 400,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 16,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#2D3436',
    marginBottom: 24,
    textAlign: 'center',
    fontFamily: 'Inter-Bold',
  },
  modalInput: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    padding: 16,
    fontSize: 16,
    color: '#2D3436',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    fontFamily: 'Inter-Regular',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
    marginTop: 16,
  },
  modalButton: {
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 24,
    backgroundColor: '#C70039',
    minWidth: 100,
    alignItems: 'center',
  },
  modalButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
    fontFamily: 'Inter-SemiBold',
  },
  emptyState: {
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    padding: 40,
    alignItems: 'center',
    marginTop: 24,
    borderWidth: 1,
    borderColor: '#EEE',
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
    marginTop: 16,
    textAlign: 'center',
    lineHeight: 24,
    fontFamily: 'Inter-Regular',
  },

  // ─────────────── Perfil (PerfilScreen) ───────────────
  screenProfile: { 
    color: '#C70039', 
    fontSize: 20, 
    fontWeight: 'bold', 
    marginTop: 10 , 
    marginBottom: 20
  },
  profileLabel: { 
    color: '#C70039', 
    fontSize: 16, 
    marginBottom: 5 
  },
  profileText: { 
    color: '#690202', 
    fontSize: 16, 
    marginBottom: 12 
  },
  editButton: { 
    backgroundColor: '#C70039', 
    borderRadius: 8, 
    paddingVertical: 15, 
    paddingHorizontal: 20, 
    alignSelf: 'center', 
    width: width * 0.9, 
    marginTop: 20, 
    alignItems: 'center' 
  },
  logoutButtonBottom: {
    backgroundColor: '#690202',
    borderRadius: 8,
    paddingVertical: 15,
    paddingHorizontal: 20,
    alignSelf: 'center',
    width: width * 0.9,
    alignItems: 'center'
  },

  // ─────────────── Configurações e Formulários ───────────────
  configContainer: {
    flex: 1,
    backgroundColor: '#FFF9F9',
    paddingHorizontal: 20,
    paddingTop: 15,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 25,
    borderBottomWidth: 1,
    borderBottomColor: '#FFE5E5',
    marginBottom: 25,
    marginTop: 10,
  },
  profileIcon: {
    backgroundColor: '#C70039',
    width: 70,
    height: 70,
    borderRadius: 35,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 20,
  },
  profileTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#690202',
    letterSpacing: -0.5,
  },
  profileSubtitle: {
    color: '#C70039',
    fontSize: 14,
    marginTop: 4,
  },
  inputContainer: {
    marginBottom: 25,
  },
  inputLabel: {
    color: '#C70039',
    fontSize: 13,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 1.2,
    marginBottom: 10,
    marginLeft: 5,
  },
  inputField: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 18,
    fontSize: 16,
    color: '#690202',
    borderWidth: 1.5,
    borderColor: '#FFE5E5',
    shadowColor: '#69020220',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 5,
  },
  readonlyField: {
    backgroundColor: '#FFF5F5',
    borderColor: '#FFD1DC',
    color: '#900C3F',
  },

  
  // Botões gerais
  buttonGroup: {
    marginTop: 35,
  },
  primaryButton: {
    backgroundColor: '#C70039',
    borderRadius: 14,
    paddingVertical: 18,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
    shadowColor: '#690202',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
  },
  secondaryButton: {
    backgroundColor: 'transparent',
    borderWidth: 2,
    borderColor: '#C70039',
  },
  buttonText: {
    color: '#FFF5F5',
    fontWeight: '700',
    fontSize: 15,
    marginLeft: 10,
    letterSpacing: 0.8,
  },

  // Feedback visual de sucesso (Perfil)
  successOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: '#FFFFFFEE',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
