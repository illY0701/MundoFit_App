// TreinoDetalhes.jsx
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Animated,
  ActivityIndicator,
  SafeAreaView,
  StatusBar,
  TouchableOpacity
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import PropTypes from 'prop-types';

const TreinoDetalhes = ({ route, navigation }) => {
  const { treino } = route.params;
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  // Simulando carregamento assíncrono
  useEffect(() => {
    const timer = setTimeout(() => {
      if (!treino) {
        setError(true);
      }
      setLoading(false);
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }).start();
    }, 800);

    return () => clearTimeout(timer);
  }, []);

  const renderHeader = () => (
    <View style={styles.header}>
      <TouchableOpacity 
        onPress={() => navigation.goBack()}
        style={styles.backButton}
      >
        <Ionicons name="chevron-back" size={28} color="#1A1A1A" />
      </TouchableOpacity>
      <Text style={styles.headerTitle}>Detalhes do Treino</Text>
    </View>
  );

  const MetaInfoItem = ({ icon, title, value }) => (
    <View style={styles.metaItem}>
      <View style={styles.metaIconContainer}>
        <Ionicons name={icon} size={20} color="#FFFFFF" />
      </View>
      <View>
        <Text style={styles.metaTitle}>{title}</Text>
        <Text style={styles.metaValue}>{value}</Text>
      </View>
    </View>
  );

  const ExerciseCard = ({ exercise, index }) => (
    <View style={styles.exerciseCard}>
      <View style={styles.exerciseNumberContainer}>
        <Text style={styles.exerciseNumber}>{index + 1}</Text>
      </View>
      <View style={styles.exerciseContent}>
        <Text style={styles.exerciseName}>{exercise.nome}</Text>
        <View style={styles.exerciseDetails}>
          <View style={styles.detailItem}>
            <Ionicons name="repeat" size={16} color="#C70039" />
            <Text style={styles.detailText}>3x {exercise.series || 12}</Text>
          </View>
          <View style={styles.detailItem}>
            <Ionicons name="time" size={16} color="#C70039" />
            <Text style={styles.detailText}>{exercise.descanso || '60s'}</Text>
          </View>
        </View>
      </View>
    </View>
  );

  const SectionTitle = ({ children }) => (
    <View style={styles.sectionTitleContainer}>
      <Text style={styles.sectionTitle}>{children}</Text>
    </View>
  );

  if (loading) {
    return (
      <SafeAreaView style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#C70039" />
      </SafeAreaView>
    );
  }

  if (error) {
    return (
      <SafeAreaView style={styles.errorContainer}>
        <Ionicons name="alert-circle" size={50} color="#C70039" />
        <Text style={styles.errorText}>Erro ao carregar o treino</Text>
      </SafeAreaView>
    );
  }

  return (
    <LinearGradient
      colors={['#FFFFFF', '#F9F9F9']}
      style={styles.container}
      start={{ x: 0.5, y: 0 }}
      end={{ x: 0.5, y: 1 }}
    >
      <StatusBar barStyle="dark-content" />
      
      {renderHeader()}

      <Animated.ScrollView
        style={{ opacity: fadeAnim }}
        contentContainerStyle={styles.contentContainer}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.titleContainer}>
          <Text style={styles.treinoTitle}>{treino.nm_treino}</Text>
        </View>

        <View style={styles.metaContainer}>
          <MetaInfoItem
            icon="calendar"
            title="Data do Treino"
            value={treino.dataFormatada}
          />
          <MetaInfoItem
            icon="time"
            title="Dia da Semana"
            value={treino.diaSemana}
          />
        </View>

        <SectionTitle>Objetivo Principal</SectionTitle>
        <Text style={styles.objectiveText}>{treino.ds_objetivo}</Text>

        <SectionTitle>Exercícios ({treino.exercicios.length})</SectionTitle>

        {treino.exercicios.map((exercise, index) => (
          <ExerciseCard
            key={`exercise-${exercise.id}-${index}`}
            exercise={exercise}
            index={index}
          />
        ))}
      </Animated.ScrollView>
    </LinearGradient>
  );
};

TreinoDetalhes.propTypes = {
  route: PropTypes.shape({
    params: PropTypes.shape({
      treino: PropTypes.shape({
        id: PropTypes.string.isRequired,
        nm_treino: PropTypes.string.isRequired,
        diaSemana: PropTypes.string.isRequired,
        ds_objetivo: PropTypes.string.isRequired,
        dataFormatada: PropTypes.string.isRequired,
        exercicios: PropTypes.arrayOf(
          PropTypes.shape({
            id: PropTypes.string.isRequired,
            nome: PropTypes.string.isRequired,
          })
        ).isRequired,
      }).isRequired,
    }).isRequired,
  }).isRequired,
  navigation: PropTypes.object.isRequired,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
  errorText: {
    color: '#C70039',
    fontSize: 18,
    marginTop: 20,
    fontWeight: '500',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  backButton: {
    padding: 8,
    marginRight: 16,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1A1A1A',
  },
  contentContainer: {
    paddingHorizontal: 24,
    paddingBottom: 40,
  },
  titleContainer: {
    marginVertical: 24,
  },
  treinoTitle: {
    fontSize: 32,
    fontWeight: '700',
    color: '#1A1A1A',
    lineHeight: 40,
  },
  metaContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 8,
  },
  metaIconContainer: {
    backgroundColor: '#C70039',
    borderRadius: 12,
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  metaTitle: {
    color: '#666',
    fontSize: 14,
    marginBottom: 4,
  },
  metaValue: {
    color: '#1A1A1A',
    fontSize: 16,
    fontWeight: '500',
  },
  sectionTitleContainer: {
    borderLeftWidth: 4,
    borderLeftColor: '#C70039',
    paddingLeft: 12,
    marginVertical: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1A1A1A',
  },
  objectiveText: {
    fontSize: 16,
    lineHeight: 24,
    color: '#444',
    marginBottom: 8,
  },
  exerciseCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  exerciseNumberContainer: {
    backgroundColor: '#FFE5E5',
    width: 40,
    height: 40,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  exerciseNumber: {
    color: '#C70039',
    fontSize: 18,
    fontWeight: '600',
  },
  exerciseContent: {
    flex: 1,
  },
  exerciseName: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1A1A1A',
    marginBottom: 8,
  },
  exerciseDetails: {
    flexDirection: 'row',
    gap: 16,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  detailText: {
    color: '#666',
    fontSize: 14,
  },
});

export default TreinoDetalhes;